sap.ui.define([
	"student01comsaptrainingux402fullscreen/ux402_fullscreen/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
