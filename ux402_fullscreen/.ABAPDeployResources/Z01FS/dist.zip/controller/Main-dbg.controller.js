sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("student01.com.sap.training.ux402.fullscreen.ux402fullscreen.controller.Main", {
            onInit: function () {

            }
        });
    });
